TESD <- function(x,y, plot=TRUE, Xlab="X",Ylab="Y", compare.based.on.x = TRUE){

  cut3 <- function(x) cut(x,quantile(x,c(0,1/3,2/3,1)),c("Low","Medium","High"), include.lowest=TRUE)

  tabs <- data.frame(x = cut3(x), y = cut3(y))

  if(compare.based.on.x){
    crosstabs <- apply(prop.table(table(tabs)),2,function(x) x/sum(x))
  } else {
    crosstabs <- apply(prop.table(table(tabs)),1,function(x) x/sum(x))
  }

  percents <- matrix(paste(round((crosstabs * 100),1),"%", sep=""), ncol=3)

  color = as.factor(apply(tabs, 1, paste, collapse=""))

  plot(x,y, cex=.5, ,
       xlab=Xlab, ylab=Ylab,
             col = c("olivedrab1","orange", "lightblue", "green", "red", "dodgerblue2", "darkgreen","brown","midnightblue")[color] )

  xq = quantile(x, c(1/3, 2/3))
  yq = quantile(y, c(1/3, 2/3))

  lines(rep(xq[1],2),c(min(y) - abs(min(y)),max(y) + abs(max(y))), col="grey50")
  lines(rep(xq[2],2),c(min(y) - abs(min(y)),max(y) + abs(max(y))), col="grey50")

  lines(c(min(x) - abs(min(x)),max(x) + abs(max(x))), rep(yq[1],2), col="grey50")
  lines(c(min(x) - abs(min(x)),max(x) + abs(max(x))), rep(yq[2],2), col="grey50")

  text(mean(x), (yq[2] + max(y))/2, percents[2,3], cex=1)
  text(mean(x), mean(y), percents[2,2], cex=1)
  text(mean(x), (yq[1] + min(y))/2, percents[2,1], cex=1)

  text((xq[1] + min(x))/2, (yq[2] + max(y))/2, percents[1,3], cex=1)
  text((xq[1] + min(x))/2, mean(y), percents[1,2], cex=1)
  text((xq[1] + min(x))/2, (yq[1] + min(y))/2, percents[1,1], cex=1)

  text((xq[2] + max(x))/2, (yq[2] + max(y))/2, percents[3,3], cex=1)
  text((xq[2] + max(x))/2, mean(y), percents[3,2], cex=1)
  text((xq[2] + max(x))/2, (yq[1] + min(y))/2, percents[3,1], cex=1)

  if(min(rowSums(crosstabs)) < .9 | max(rowSums(crosstabs)) > 1.1)
    warning("\n\nPairwise groups have unexpected sizes, be careful! The variables may not be suitable for TESD.\n
            To get the estimated TESD, calculate the correlation between x and y and check TESD tables.")

  if(compare.based.on.x)
    warning(c("\n\n", paste("Interpret it as: Proportions of", Ylab, "if", Xlab," is low, medium or high, respectively"), "\n"))

  if(!compare.based.on.x)
    warning(c("\n\n", paste("Interpret it as: Proportions of", Xlab, "if", Ylab," is low, medium or high, respectively"), "\n"))


  list(x.proportions = prop.table(table(tabs$x)),
       y.propoprtions = prop.table(table(tabs$y)),
       cross.tabulations = table(tabs),
       TESD.table = crosstabs,
       x.group.sums.according.to.y.levels = colSums(crosstabs),
       y.group.sums.according.to.x.levels = rowSums(crosstabs))
}
